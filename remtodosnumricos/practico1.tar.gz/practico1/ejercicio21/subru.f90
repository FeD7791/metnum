module subru

contains

    subroutine sum(z,w,ss)
    implicit none
    real(kind(1.)),intent(in)   :: z,w
    real(kind(1.)),intent(out)  :: ss
    ss=z+w 
    end subroutine sum

end module subru
